package com.ai.hynova;
import android.service.voice.VoiceInteractionSession; import android.content.Context; import android.content.Intent;
public class HyNovaVoiceInteractionSession extends VoiceInteractionSession {
 public HyNovaVoiceInteractionSession(Context context){super(context);}
 @Override public void onShow(android.os.Bundle args,int flags){super.onShow(args,flags); Intent i=new Intent(this.getContext(),MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);getContext().startActivity(i);hide();}
}
