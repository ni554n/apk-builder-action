package com.ai.hynova;
import android.content.Context;import android.content.Intent;import android.content.pm.PackageManager;
/** Explicit, user-initiated app launcher. Android will still enforce app and permission restrictions. */
public class VoiceAutomationBridge {
 private final Context context; public VoiceAutomationBridge(Context c){context=c.getApplicationContext();}
 public boolean openApp(String packageName){if(packageName==null||packageName.trim().isEmpty())return false;PackageManager pm=context.getPackageManager();Intent i=pm.getLaunchIntentForPackage(packageName.trim());if(i==null)return false;i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);try{context.startActivity(i);return true;}catch(Exception e){return false;}}
}
