package com.ai.hynova;
import android.accessibilityservice.AccessibilityService;import android.view.accessibility.AccessibilityEvent;
/** Optional service. It deliberately does not inspect screen text, click controls, unlock devices, or bypass security. */
public class HyNovaAccessibilityService extends AccessibilityService {
 @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* Reserved for future transparent, user-authorized accessibility features. */ }
 @Override public void onInterrupt() { }
}
