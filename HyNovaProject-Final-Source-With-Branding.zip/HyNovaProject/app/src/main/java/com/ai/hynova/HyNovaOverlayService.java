package com.ai.hynova;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import androidx.core.app.NotificationCompat;

/** User-enabled floating companion bubble. Tap it to reopen HyNova; drag to reposition. */
public class HyNovaOverlayService extends Service {
 private static final String CHANNEL="hynova_overlay"; private WindowManager wm; private View bubble; private WindowManager.LayoutParams params;
 @Override public void onCreate(){super.onCreate();createChannel();Notification n=new NotificationCompat.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("HyNova AI").setContentText("Floating companion active — tap bubble to open").setOngoing(true).build(); if(Build.VERSION.SDK_INT>=29)startForeground(8001,n);else startForeground(8001,n);
  if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this)){stopSelf();return;} wm=(WindowManager)getSystemService(WINDOW_SERVICE); TextView v=new TextView(this);v.setText("✦\nNova");v.setTextColor(Color.WHITE);v.setTextSize(13);v.setGravity(Gravity.CENTER);v.setPadding(12,8,12,8);v.setBackgroundColor(0xEE5436C8);bubble=v;
  int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
  params=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);params.gravity=Gravity.TOP|Gravity.END;params.x=24;params.y=180;
  v.setOnClickListener(w->{Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);});v.setOnTouchListener(new View.OnTouchListener(){int sx,sy;float tx,ty;public boolean onTouch(View view,android.view.MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){sx=params.x;sy=params.y;tx=e.getRawX();ty=e.getRawY();return false;}if(e.getAction()==MotionEvent.ACTION_MOVE){params.x=sx+(int)(tx-e.getRawX());params.y=sy+(int)(e.getRawY()-ty);try{wm.updateViewLayout(bubble,params);}catch(Exception ignored){}return true;}return false;}});
  try{wm.addView(v,params);}catch(Exception e){stopSelf();}}
 private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"HyNova Floating Companion",NotificationManager.IMPORTANCE_LOW);NotificationManager m=getSystemService(NotificationManager.class);if(m!=null)m.createNotificationChannel(c);}}
 @Override public int onStartCommand(Intent i,int flags,int id){return START_STICKY;} @Override public IBinder onBind(Intent i){return null;}
 @Override public void onDestroy(){if(bubble!=null&&wm!=null)try{wm.removeView(bubble);}catch(Exception ignored){}super.onDestroy();}
}
