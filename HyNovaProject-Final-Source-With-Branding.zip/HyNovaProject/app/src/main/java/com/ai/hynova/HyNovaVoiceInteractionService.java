package com.ai.hynova;
import android.service.voice.VoiceInteractionService;
/** May be selected by the user as the system digital assistant in Android Settings. */
public class HyNovaVoiceInteractionService extends VoiceInteractionService { }
